# DjangoProject

This is a Django project for managing student information.

## Setup Instructions

### Prerequisites

- Python 3.13
- Pipenv
- MySQL

### Installation

1. **Clone the repository**:

   ```sh
   git clone https://github.com/nixiesimbajon/DjangoProject.git
   cd DjangoProject